
import javax.swing.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class VaultDashboard extends JFrame {
    private JTable fileTable;
    private DefaultTableModel tableModel;
    private JButton uploadButton;
    private JButton downloadButton;
    private VaultManager vaultManager;
    private String username;

    public VaultDashboard(String username) {
        this.username = username;
        vaultManager = new VaultManager();

        setTitle("Vault Dashboard");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Files");
        fileTable = new JTable(tableModel);
        refreshFileList();

        uploadButton = new JButton("Upload");
        downloadButton = new JButton("Download");

        JPanel panel = new JPanel();
        panel.add(new JScrollPane(fileTable));
        panel.add(uploadButton);
        panel.add(downloadButton);

        add(panel);

        uploadButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    try {
                        vaultManager.uploadFile(username, selectedFile);
                        refreshFileList();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "File upload failed");
                    }
                }
            }
        });

        downloadButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = fileTable.getSelectedRow();
                if (selectedRow != -1) {
                    String fileName = (String) tableModel.getValueAt(selectedRow, 0);
                    File file = vaultManager.downloadFile(username, fileName);
                    if (file != null) {
                        JFileChooser fileChooser = new JFileChooser();
                        fileChooser.setSelectedFile(file);
                        int result = fileChooser.showSaveDialog(null);
                        if (result == JFileChooser.APPROVE_OPTION) {
                            File saveFile = fileChooser.getSelectedFile();
                            try {
                                Files.copy(file.toPath(), saveFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                                JOptionPane.showMessageDialog(null, "File downloaded successfully");
                            } catch (IOException ex) {
                                ex.printStackTrace();
                                JOptionPane.showMessageDialog(null, "File download failed");
                            }
                        }
                    }
                }
            }
        });
    }

    private void refreshFileList() {
        tableModel.setRowCount(0);
        List<String> files = vaultManager.listFiles(username);
        for (String file : files) {
            tableModel.addRow(new Object[]{file});
        }
    }
}
