
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class VaultManager {
    private static final String VAULT_DIR = "vault";

    public VaultManager() {
        File vaultDir = new File(VAULT_DIR);
        if (!vaultDir.exists()) {
            vaultDir.mkdir();
        }
    }

    public void uploadFile(String username, File file) throws IOException {
        File userDir = new File(VAULT_DIR, username);
        if (!userDir.exists()) {
            userDir.mkdir();
        }
        Files.copy(file.toPath(), new File(userDir, file.getName()).toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    public File downloadFile(String username, String fileName) {
        File userDir = new File(VAULT_DIR, username);
        File file = new File(userDir, fileName);
        return file.exists() ? file : null;
    }

    public List<String> listFiles(String username) {
        File userDir = new File(VAULT_DIR, username);
        if (userDir.exists() && userDir.isDirectory()) {
            return Arrays.asList(userDir.list());
        }
        return new ArrayList<>();
    }
}
