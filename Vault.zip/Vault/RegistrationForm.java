package ui;

import javax.swing.*;
import java.awt.event.*;

public class RegistrationForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton registerButton;
    private AuthManager authManager;

    public RegistrationForm() {
        authManager = new AuthManager();

        setTitle("Register");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        usernameField = new JTextField(15);
        passwordField = new JPasswordField(15);
        registerButton = new JButton("Register");

        JPanel panel = new JPanel();
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(registerButton);

        add(panel);

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (authManager.register(username, password)) {
                    JOptionPane.showMessageDialog(null, "Registration successful");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Registration failed");
                }
            }
        });
    }
}
