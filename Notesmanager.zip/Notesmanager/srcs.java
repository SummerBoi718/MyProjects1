import java.io.FileInputStream;//to read from the files
import java.io.FileOutputStream;//to write into files
import java.util.Scanner;//to get the user input
import java.lang.Exception;//idk, no use for now
import java.io.File;//to create the folder for text files
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.StringBuilder;
import java.nio.file.Path;
import java.nio.file.Paths;
//this program will be a notes manager
//the first step of the program will be creating the dir where note or txt files will be stored
//the second step is to get user input for the name of the file which is the title
//the next step is to get the user input for the contents of the file
//the contents will be mostly one liner as the scanner will  be used to get user input
public class srcs{
	public static void main(String x[]){
	    Settings obj=new Settings();
    	String folderPath=obj.path;
    File folder= new File(folderPath);
    if(!folder.exists()){
        boolean crtd=folder.mkdirs();
        if(crtd){
            System.out.println("Folder Successfully created");
            
        }else{
            System.out.println("Folder Unsuccessfully created");
        }
    }else{
        System.out.println("Folder already exists");
    }
    //test if notes will be stored into the notes dir
	    //Notes n=new Notes("first","Idk man");
    /*n.createNote();
    n.writeToNote(); */
   // Notes b=new Notes("second","test test test");   
	     Notes c=new Notes("important"," just kidding lmao you got fooled brother");
	     Notes wtf=new Notes("Testing"," For real bro? Again?");
	}
    
}
class Notes{
    public String title;
    public String content;
    public String notePath;
    public FileOutputStream innerNote;
    public Settings settings;
    Notes(String titlex, String contentx){
        this.title=titlex;
        this.content=contentx;
        this.notePath=settings.path+"/"+titlex+".txt";
        this.createNote();
        this.writeToNote();
    }
    /*public void writeTitle(
        
    )*/
    public void createNote(){
        try{
            FileOutputStream note=new FileOutputStream(notePath);
            this.innerNote=note;
           // note.close();
        }catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
        }/*catch(IOException ex){
            System.out.println(ex.getMessage());
        }*/
        
    }
    public void writeToNote(){
        try{
            byte[] bytecontents=content.getBytes();
            byte[] bytetitle=title.getBytes();
            innerNote.write(bytetitle);
            innerNote.write('\n');
            innerNote.write(bytecontents);
        }catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
}
class Settings{
    public static String path;
    public static String sort;
    public static String secretFeauture;
    
    Settings(){
        try{
            //FileInputStream in=new FileInputStream("//storage//emulated//0//Practice_space//Notesmanager//config//settings.txt");
            Path inputstream=Paths.get("config//settings.txt");
            File file=inputstream.toFile();
            FileInputStream in=new FileInputStream(file);
            int chars;
            StringBuilder str=new StringBuilder();
            while((chars = in.read()) != -1){
            str.append((char) chars);
            }
            path=str.toString();
        }catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
        
    }
}
class NotesManager{
    //static methods for managing note
    public static void deleteNote(Notes note){
        
    }
    public static void saveNote(Notes note){
        
    }
}
