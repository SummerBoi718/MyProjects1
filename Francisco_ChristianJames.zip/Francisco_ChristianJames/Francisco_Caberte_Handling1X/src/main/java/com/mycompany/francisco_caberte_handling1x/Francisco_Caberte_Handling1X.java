/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.francisco_caberte_handling1x;

/**
 *
 * @author STIWNU
 */
public class Francisco_Caberte_Handling1X {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
